---
document_type: state-of-the-art
series: Notebooks on Ecological Revision and Technological Sovereignty
number: 4
title: From prototype to conformity — standards, testing, professional accountability, and release of bamboo components
author: Fabio Takwara
author_orcid: 0000-0001-8815-3885
year: 2026
version: 1.2
document_status: published-on-zenodo
identifier: https://doi.org/10.5281/zenodo.21738559
text_license: CC-BY-4.0
method: repository-guided-normative-scope-review
revision_date: 2026-08-01
curation_responsible: Fabio Takwara
tipo_documental: estado-da-arte
estado_documental: publicado-no-zenodo
responsavel_curadoria: 'Fabio Takwara'
nota_versao: 'resolved — R-10: Zenodo API query (2026-08-01) confirms that record 10.5281/zenodo.21515361 corresponded to version 1.1 and that the new deposit (DOI 10.5281/zenodo.21738559) is version 1.2, according to the Zenodo version field (conceptual DOI 10.5281/zenodo.21515209); DOI 10.5281/zenodo.21515210 cited by Notebook 5 is version 1.0 (correct as citation of the previous version). Front matter updated to 1.2.'
editorial_note: 'P-01 resolved (decision by Fabio, 2026-08-01): the IFB Campus Planaltina faculty member cited in the Anais as Prof. Dr. Vicente Virgolino de Souza Neto is the same person as the Acervo profile Vicente de Paulo Borges Virgolino da Silva (coordinator of the Agronomy undergraduate program). Canonical form adopted: Vicente de Paulo Borges Virgolino da Silva. The Anais were not altered (historical record).'

---

# From prototype to conformity

## Standards, testing, professional accountability, and release of bamboo components

**Fabio Takwara**  
[ORCID 0000-0001-8815-3885](https://orcid.org/0000-0001-8815-3885)  
*Notebooks on Ecological Revision and Technological Sovereignty, n. 4 — version 1.2, August 1, 2026*  

[![DOI](https://zenodo.org/badge/DOI/10.5281/zenodo.21738559.svg)](https://doi.org/10.5281/zenodo.21738559)
[![Versão em Português](https://img.shields.io/badge/Idioma-Portugu%C3%AAs-green.svg)](caderno-04-prototipo-conformidade-normas-ensaios.md)


> **Editorial status:** Public edition published on Zenodo (version 1.2, DOI [10.5281/zenodo.21738559](https://doi.org/10.5281/zenodo.21738559)). This text organizes a roadmap for research and conformity; it does not constitute a structural engineering design, legal opinion, certification, Technical Assessment Document (DATec), or technical responsibility record (ART/RRT).

## Abstract

This notebook examines the transition from prototype to conformity for bamboo construction components, particularly when culms are conditioned, coated, filled, or joined to polymers. The review compares Brazilian and international documents on structural design, culm characterization and grading, engineered bamboo products, building performance, reaction-to-fire testing, technical assessment of innovative products, and professional responsibility. No single standard can qualify the complete hybrid system. Conformity must be assembled across layers — feedstock, process, interface, component, connection, subsystem, building, and production — and linked to a defined application and exposure class. ISO 22156:2021 excludes engineered bamboo products and reinforced materials in which bamboo is not the primary load-bearing constituent; engineered-product test standards do not automatically cover filled natural culms; certificates for isolated polymers do not classify the finished component. In Brazil, innovative construction products without sufficient prescriptive coverage may require performance assessment through SiNAT, including testing and production-control audits. The notebook proposes an application–requirement–document–test–evidence–responsibility matrix and eight release gates. Standardization is treated as a decision architecture in which every claim identifies its object, method, version, boundary, and accountable professional.

**Keywords:** structural bamboo; standardization; conformity; testing; innovative product; SiNAT; production control; professional responsibility.

---

## 1. Introduction

The first three notebooks formed a clear progression. Notebook 1 examined socioecological preservation; Notebook 2 followed the conditioned culm up to the protected component; and Notebook 3 analyzed conditions to convert components and equipment into territorial productive capacity. Notebook 4 introduces the question bridging them all:

> **Which standards, test methods, technical responsibilities, and quality controls permit releasing a bamboo component for a defined building application?**

Standards do not validate abstract ideas. They delineate objects, boundaries, sampling, criteria, and professional accountabilities. A test method produces data without defining acceptance. A design standard requires characteristic properties obtained elsewhere. A certificate for an isolated raw material sample may be authentic without validating the finished component.

## 2. Eight layers of conformity

1. **Feedstock:** species, age, provenance, sorting, defect grading (ABNT NBR 16828-2, ISO 19624);
2. **Modification process:** preservation, alkalinization, neutralization, drying (traceable parameters);
3. **Interface and bonding:** bamboo–bio-PU compatibility and physical-chemical stability;
4. **Isolated component:** mechanical strength, bending, axial compression, water tightness, durability;
5. **Connections and joints:** load transfer at nodes, metallic/polymeric connectors (ISO 22156);
6. **Subsystem and building performance:** structural safety, fire reaction, acoustic/thermal performance (ABNT NBR 15575);
7. **Complete building:** global stability, foundation interfaces, design service life (VUP);
8. **Production control and traceability:** manufacturing audits, statistical quality control, professional accountability (SiNAT, Confea/Crea, CAU).

---

## References

ASSOCIAÇÃO BRASILEIRA DE NORMAS TÉCNICAS. *ABNT NBR 16828-1:2020 — Bamboo structures — Part 1: Structural design*. Rio de Janeiro: ABNT, 2020.

ASSOCIAÇÃO BRASILEIRA DE NORMAS TÉCNICAS. *ABNT NBR 16828-2:2020 — Bamboo structures — Part 2: Determination of physical and mechanical properties*. Rio de Janeiro: ABNT, 2020.

ASSOCIAÇÃO BRASILEIRA DE NORMAS TÉCNICAS. *ABNT NBR 15575 — Residential buildings — Performance*. Rio de Janeiro: ABNT.

BRASIL. Ministry of Cities. *SiNAT — National System for Technical Assessment of Innovative Products*. 2026.

HONG, Chaokun et al. Review on connections for original bamboo structures. *Journal of Renewable Materials*, v. 7, n. 8, p. 713–730, 2019. DOI: [10.32604/jrm.2019.07647](https://doi.org/10.32604/jrm.2019.07647).

INTERNATIONAL ORGANIZATION FOR STANDARDIZATION. *ISO 19624:2018 — Bamboo structures — Grading of bamboo culms — Basic principles and procedures*. Geneva: ISO, 2018.

INTERNATIONAL ORGANIZATION FOR STANDARDIZATION. *ISO 22156:2021 — Bamboo structures — Bamboo culms — Structural design*. Geneva: ISO, 2021.

INTERNATIONAL ORGANIZATION FOR STANDARDIZATION. *ISO 22157:2019 — Bamboo structures — Determination of physical and mechanical properties of bamboo culms — Test methods*. Geneva: ISO, 2019.

MARÇAL, Vitor Hugo Silva. *Análise comparativa de normas técnicas internacionais para o emprego do bambu-colmo em estruturas prediais*. 2018. M.Sc. thesis — University of Brasília, Brasília, 2018.

TAKWARA, Fabio. *Preservação do bambu sob perspectiva socioecológica: eficácia, durabilidade, toxicidade e circularidade dos tratamentos*. Notebooks on Ecological Revision and Technological Sovereignty, n. 1, version 1.1, August 1, 2026. DOI: [10.5281/zenodo.21738428](https://doi.org/10.5281/zenodo.21738428).

TAKWARA, Fabio. *From conditioned culm to protected component: interfaces, bio-based PU, internal filling, and integrated validation*. Notebooks on Ecological Revision and Technological Sovereignty, n. 2, deposited version 1.2, July 23, 2026. DOI: [10.5281/zenodo.21514977](https://doi.org/10.5281/zenodo.21514977).

TAKWARA, Fabio. *From component to territorial productive capacity: distributed manufacturing, quality control, and autonomy*. Notebooks on Ecological Revision and Technological Sovereignty, n. 3, version 1.1, August 1, 2026. DOI: [10.5281/zenodo.21738550](https://doi.org/10.5281/zenodo.21738550).

---

## Authorship, curation, and transparency

**Authorship and perspective:** Fabio Takwara.  
**Documentary base:** Acervo Soberania Tecnológica, official catalogs, identified references.  
**Authorial contribution:** Organization of layered conformity, decision matrix, and eight release gates.  
**Editorial and analytical support:** Artificial intelligence tools under author direction and responsibility.  
**Text license:** CC BY 4.0.

### Citation format

TAKWARA, Fabio. *From prototype to conformity: standards, testing, professional accountability, and release of bamboo components*. Notebooks on Ecological Revision and Technological Sovereignty, n. 4, version 1.2, August 1, 2026. DOI: [10.5281/zenodo.21738559](https://doi.org/10.5281/zenodo.21738559).
